const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const { load, save } = require('../db');
const { SECRET } = require('../middleware/auth');

const router = express.Router();

router.post('/register', (req, res) => {
  const { username, password, name } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  const db = load();
  const exists = db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  if (exists) return res.status(409).json({ error: 'That username is already taken' });

  const passwordHash = bcrypt.hashSync(password, 10);
  const user = {
    id: uuid(),
    username,
    name: name || username,
    passwordHash,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  save(db);

  const token = jwt.sign({ id: user.id, username: user.username, name: user.name }, SECRET, { expiresIn: '7d' });
  res.status(201).json({ token, user: { id: user.id, username: user.username, name: user.name } });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const db = load();
  const user = db.users.find(u => u.username.toLowerCase() === (username || '').toLowerCase());
  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  const token = jwt.sign({ id: user.id, username: user.username, name: user.name }, SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, name: user.name } });
});

// Used by the frontend to look up teammates by username when adding project members
router.get('/users', (req, res) => {
  const db = load();
  res.json(db.users.map(u => ({ id: u.id, username: u.username, name: u.name })));
});

module.exports = router;
