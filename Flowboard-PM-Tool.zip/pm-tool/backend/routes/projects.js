const express = require('express');
const { v4: uuid } = require('uuid');
const { load, save } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

function projectSummary(db, project) {
  const taskCount = db.tasks.filter(t => t.projectId === project.id).length;
  const doneCount = db.tasks.filter(t => t.projectId === project.id && t.status === 'done').length;
  return { ...project, taskCount, doneCount };
}

// List projects the current user owns or is a member of
router.get('/', (req, res) => {
  const db = load();
  const mine = db.projects.filter(p => p.ownerId === req.user.id || p.memberIds.includes(req.user.id));
  res.json(mine.map(p => projectSummary(db, p)));
});

// Create a new project (creator becomes owner + first member)
router.post('/', (req, res) => {
  const { name, description } = req.body;
  if (!name) return res.status(400).json({ error: 'Project name is required' });
  const db = load();
  const project = {
    id: uuid(),
    name,
    description: description || '',
    ownerId: req.user.id,
    memberIds: [req.user.id],
    createdAt: new Date().toISOString()
  };
  db.projects.push(project);
  save(db);
  res.status(201).json(project);
});

function getAccessibleProject(db, projectId, userId) {
  const project = db.projects.find(p => p.id === projectId);
  if (!project) return null;
  if (project.ownerId !== userId && !project.memberIds.includes(userId)) return null;
  return project;
}

// Get one project with its tasks + comments + members
router.get('/:id', (req, res) => {
  const db = load();
  const project = getAccessibleProject(db, req.params.id, req.user.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const tasks = db.tasks
    .filter(t => t.projectId === project.id)
    .map(t => ({
      ...t,
      comments: db.comments
        .filter(c => c.taskId === t.id)
        .map(c => ({ ...c, author: (db.users.find(u => u.id === c.userId) || {}).name }))
        .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    }));

  const members = project.memberIds
    .map(id => db.users.find(u => u.id === id))
    .filter(Boolean)
    .map(u => ({ id: u.id, username: u.username, name: u.name }));

  res.json({ ...project, members, tasks });
});

// Add a member to a project by username
router.post('/:id/members', (req, res) => {
  const { username } = req.body;
  const db = load();
  const project = getAccessibleProject(db, req.params.id, req.user.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const user = db.users.find(u => u.username.toLowerCase() === (username || '').toLowerCase());
  if (!user) return res.status(404).json({ error: 'No user with that username' });
  if (!project.memberIds.includes(user.id)) {
    project.memberIds.push(user.id);
    save(db);
    const io = req.app.get('io');
    io.to(`project:${project.id}`).emit('member:added', { projectId: project.id, member: { id: user.id, username: user.username, name: user.name } });
  }
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const db = load();
  const project = db.projects.find(p => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  if (project.ownerId !== req.user.id) return res.status(403).json({ error: 'Only the owner can delete this project' });

  db.projects = db.projects.filter(p => p.id !== project.id);
  const removedTaskIds = db.tasks.filter(t => t.projectId === project.id).map(t => t.id);
  db.tasks = db.tasks.filter(t => t.projectId !== project.id);
  db.comments = db.comments.filter(c => !removedTaskIds.includes(c.taskId));
  save(db);
  const io = req.app.get('io');
  io.to(`project:${project.id}`).emit('project:deleted', { projectId: project.id });
  res.json({ ok: true });
});

module.exports = router;
