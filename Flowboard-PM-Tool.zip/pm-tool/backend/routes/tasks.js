const express = require('express');
const { v4: uuid } = require('uuid');
const { load, save } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const STATUSES = ['todo', 'in_progress', 'done'];

function canAccessProject(db, projectId, userId) {
  const project = db.projects.find(p => p.id === projectId);
  if (!project) return null;
  if (project.ownerId !== userId && !project.memberIds.includes(userId)) return null;
  return project;
}

function hydrate(db, task) {
  return {
    ...task,
    comments: db.comments
      .filter(c => c.taskId === task.id)
      .map(c => ({ ...c, author: (db.users.find(u => u.id === c.userId) || {}).name }))
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
  };
}

// Create a task inside a project
router.post('/project/:projectId', (req, res) => {
  const { title, description, assigneeId } = req.body;
  if (!title) return res.status(400).json({ error: 'Task title is required' });
  const db = load();
  const project = canAccessProject(db, req.params.projectId, req.user.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const task = {
    id: uuid(),
    projectId: project.id,
    title,
    description: description || '',
    status: 'todo',
    assigneeId: assigneeId || null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  db.tasks.push(task);
  save(db);

  const io = req.app.get('io');
  io.to(`project:${project.id}`).emit('task:created', hydrate(db, task));
  res.status(201).json(hydrate(db, task));
});

// Update a task: title, description, status (drag-drop between columns), assignee
router.patch('/:id', (req, res) => {
  const db = load();
  const task = db.tasks.find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  const project = canAccessProject(db, task.projectId, req.user.id);
  if (!project) return res.status(403).json({ error: 'Not allowed' });

  const { title, description, status, assigneeId } = req.body;
  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (status !== undefined) {
    if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    task.status = status;
  }
  if (assigneeId !== undefined) task.assigneeId = assigneeId;
  task.updatedAt = new Date().toISOString();
  save(db);

  const io = req.app.get('io');
  io.to(`project:${project.id}`).emit('task:updated', hydrate(db, task));
  res.json(hydrate(db, task));
});

// Delete a task
router.delete('/:id', (req, res) => {
  const db = load();
  const task = db.tasks.find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  const project = canAccessProject(db, task.projectId, req.user.id);
  if (!project) return res.status(403).json({ error: 'Not allowed' });

  db.tasks = db.tasks.filter(t => t.id !== task.id);
  db.comments = db.comments.filter(c => c.taskId !== task.id);
  save(db);

  const io = req.app.get('io');
  io.to(`project:${project.id}`).emit('task:deleted', { id: task.id, projectId: project.id });
  res.json({ ok: true });
});

// Add a comment to a task
router.post('/:id/comments', (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Comment text is required' });
  const db = load();
  const task = db.tasks.find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  const project = canAccessProject(db, task.projectId, req.user.id);
  if (!project) return res.status(403).json({ error: 'Not allowed' });

  const comment = {
    id: uuid(),
    taskId: task.id,
    userId: req.user.id,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };
  db.comments.push(comment);
  save(db);

  const io = req.app.get('io');
  const payload = { ...comment, author: req.user.name, projectId: project.id };
  io.to(`project:${project.id}`).emit('comment:created', payload);
  res.status(201).json(payload);
});

module.exports = router;
