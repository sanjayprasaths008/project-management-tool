const path = require('path');
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

const { SECRET } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const taskRoutes = require('./routes/tasks');

const PORT = process.env.PORT || 4000;

const app = express();
app.use(cors());
app.use(express.json());

// --- API routes ---
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/tasks', taskRoutes);

// --- Serve the frontend (static site) ---
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');
app.use(express.static(FRONTEND_DIR));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(FRONTEND_DIR, 'index.html'));
});

// --- HTTP + WebSocket server ---
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.set('io', io);

// Authenticate socket connections with the same JWT used for the REST API
io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error('Missing auth token'));
  try {
    socket.user = jwt.verify(token, SECRET);
    next();
  } catch (e) {
    next(new Error('Invalid auth token'));
  }
});

io.on('connection', (socket) => {
  socket.on('project:join', (projectId) => {
    socket.join(`project:${projectId}`);
  });
  socket.on('project:leave', (projectId) => {
    socket.leave(`project:${projectId}`);
  });
});

server.listen(PORT, () => {
  console.log(`PM Tool server running at http://localhost:${PORT}`);
});
