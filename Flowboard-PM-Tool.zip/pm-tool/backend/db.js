// Lightweight file-based JSON "database".
// Good enough for a demo / small team tool without requiring native builds.
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data.json');

function defaultData() {
  return {
    users: [],      // { id, username, passwordHash, name, createdAt }
    projects: [],   // { id, name, description, ownerId, memberIds: [], createdAt }
    tasks: [],       // { id, projectId, title, description, status, assigneeId, createdAt, updatedAt }
    comments: []      // { id, taskId, userId, text, createdAt }
  };
}

function load() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData(), null, 2));
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return defaultData();
  }
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { load, save };
