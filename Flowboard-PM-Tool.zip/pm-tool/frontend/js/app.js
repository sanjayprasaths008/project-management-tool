// ===================== State & helpers =====================
const API = '/api';
let state = {
  token: localStorage.getItem('pm_token') || null,
  user: JSON.parse(localStorage.getItem('pm_user') || 'null'),
  projects: [],
  currentProject: null, // full project object w/ tasks
  socket: null
};

function authHeaders() {
  return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + state.token };
}

async function api(method, path, body) {
  const res = await fetch(API + path, {
    method,
    headers: authHeaders(),
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2400);
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active-screen'));
  document.getElementById(id).classList.add('active-screen');
}

function openModal(id) {
  document.getElementById('modal-overlay').classList.add('active');
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}
function closeModals() {
  document.getElementById('modal-overlay').classList.remove('active');
}

// ===================== Auth =====================
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('form-' + btn.dataset.tab).classList.add('active');
  });
});

document.getElementById('form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl = document.getElementById('login-error');
  errEl.textContent = '';
  try {
    const data = await api('POST', '/auth/login', { username, password });
    onAuthSuccess(data);
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById('form-register').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('register-name').value.trim();
  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;
  const errEl = document.getElementById('register-error');
  errEl.textContent = '';
  try {
    const data = await api('POST', '/auth/register', { name, username, password });
    onAuthSuccess(data);
  } catch (err) {
    errEl.textContent = err.message;
  }
});

function onAuthSuccess(data) {
  state.token = data.token;
  state.user = data.user;
  localStorage.setItem('pm_token', data.token);
  localStorage.setItem('pm_user', JSON.stringify(data.user));
  bootApp();
}

document.getElementById('btn-logout').addEventListener('click', () => {
  localStorage.removeItem('pm_token');
  localStorage.removeItem('pm_user');
  if (state.socket) state.socket.disconnect();
  state = { token: null, user: null, projects: [], currentProject: null, socket: null };
  showScreen('screen-auth');
});

// ===================== Boot =====================
async function bootApp() {
  document.getElementById('me-name').textContent = state.user.name;
  showScreen('screen-app');
  connectSocket();
  await loadProjects();
}

function connectSocket() {
  state.socket = io({ auth: { token: state.token } });
  state.socket.on('task:created', (task) => {
    if (state.currentProject && task.projectId === state.currentProject.id) {
      state.currentProject.tasks.push(task);
      renderBoard();
    }
    refreshProjectCounts();
  });
  state.socket.on('task:updated', (task) => {
    if (state.currentProject && task.projectId === state.currentProject.id) {
      const idx = state.currentProject.tasks.findIndex(t => t.id === task.id);
      if (idx >= 0) state.currentProject.tasks[idx] = task;
      renderBoard();
      if (document.getElementById('modal-task-detail').classList.contains('active')
          && document.getElementById('modal-task-detail').dataset.taskId === task.id) {
        openTaskDetail(task.id);
      }
    }
    refreshProjectCounts();
  });
  state.socket.on('task:deleted', ({ id, projectId }) => {
    if (state.currentProject && projectId === state.currentProject.id) {
      state.currentProject.tasks = state.currentProject.tasks.filter(t => t.id !== id);
      renderBoard();
    }
    refreshProjectCounts();
  });
  state.socket.on('comment:created', (comment) => {
    if (state.currentProject) {
      const task = state.currentProject.tasks.find(t => t.id === comment.taskId);
      if (task) {
        task.comments = task.comments || [];
        task.comments.push(comment);
        renderBoard();
        if (document.getElementById('modal-task-detail').classList.contains('active')
            && document.getElementById('modal-task-detail').dataset.taskId === task.id) {
          renderComments(task);
        }
      }
    }
  });
  state.socket.on('member:added', ({ projectId, member }) => {
    if (state.currentProject && projectId === state.currentProject.id) {
      state.currentProject.members.push(member);
      renderMembers();
      populateAssigneeSelect();
    }
  });
  state.socket.on('project:deleted', ({ projectId }) => {
    if (state.currentProject && state.currentProject.id === projectId) {
      state.currentProject = null;
      showView('view-dashboard');
      toast('This project was deleted');
    }
    loadProjects();
  });
}

// ===================== Projects =====================
async function loadProjects() {
  state.projects = await api('GET', '/projects');
  renderProjectNav();
}

function renderProjectNav() {
  const nav = document.getElementById('project-nav');
  nav.innerHTML = '';
  state.projects.forEach(p => {
    const item = document.createElement('div');
    item.className = 'project-nav-item' + (state.currentProject && state.currentProject.id === p.id ? ' active' : '');
    item.innerHTML = `<span>${escapeHtml(p.name)}</span><span class="pn-count">${p.doneCount}/${p.taskCount}</span>`;
    item.addEventListener('click', () => openProject(p.id));
    nav.appendChild(item);
  });
}

async function refreshProjectCounts() {
  state.projects = await api('GET', '/projects');
  renderProjectNav();
}

document.getElementById('btn-new-project').addEventListener('click', () => {
  document.getElementById('np-name').value = '';
  document.getElementById('np-desc').value = '';
  document.getElementById('np-error').textContent = '';
  openModal('modal-new-project');
});

document.getElementById('np-submit').addEventListener('click', async () => {
  const name = document.getElementById('np-name').value.trim();
  const description = document.getElementById('np-desc').value.trim();
  const errEl = document.getElementById('np-error');
  if (!name) { errEl.textContent = 'Give your project a name'; return; }
  try {
    const project = await api('POST', '/projects', { name, description });
    closeModals();
    await loadProjects();
    openProject(project.id);
  } catch (err) {
    errEl.textContent = err.message;
  }
});

function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

async function openProject(id) {
  const project = await api('GET', '/projects/' + id);
  state.currentProject = project;
  if (state.socket) state.socket.emit('project:join', id);
  renderProjectNav();
  document.getElementById('board-title').textContent = project.name;
  document.getElementById('board-desc').textContent = project.description || '';
  renderMembers();
  populateAssigneeSelect();
  renderBoard();
  showView('view-board');
}

function renderMembers() {
  const wrap = document.getElementById('board-members');
  wrap.innerHTML = '';
  state.currentProject.members.forEach(m => {
    const chip = document.createElement('div');
    chip.className = 'member-chip';
    chip.title = m.name;
    chip.textContent = (m.name || m.username).slice(0, 1).toUpperCase();
    wrap.appendChild(chip);
  });
}

document.getElementById('btn-add-member').addEventListener('click', () => {
  document.getElementById('am-username').value = '';
  document.getElementById('am-error').textContent = '';
  openModal('modal-add-member');
});

document.getElementById('am-submit').addEventListener('click', async () => {
  const username = document.getElementById('am-username').value.trim();
  const errEl = document.getElementById('am-error');
  if (!username) { errEl.textContent = 'Enter a username'; return; }
  try {
    await api('POST', `/projects/${state.currentProject.id}/members`, { username });
    closeModals();
    toast('Teammate added');
    await openProject(state.currentProject.id);
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById('btn-delete-project').addEventListener('click', async () => {
  if (!confirm('Delete this project and all of its tasks? This cannot be undone.')) return;
  await api('DELETE', '/projects/' + state.currentProject.id);
  state.currentProject = null;
  showView('view-dashboard');
  await loadProjects();
  toast('Project deleted');
});

// ===================== Board / Tasks =====================
function populateAssigneeSelect() {
  const sel = document.getElementById('nt-assignee');
  sel.innerHTML = '<option value="">Unassigned</option>';
  state.currentProject.members.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.textContent = m.name;
    sel.appendChild(opt);
  });
}

function renderBoard() {
  const columns = { todo: [], in_progress: [], done: [] };
  state.currentProject.tasks.forEach(t => columns[t.status].push(t));

  ['todo', 'in_progress', 'done'].forEach(status => {
    const col = document.getElementById('col-' + status);
    col.innerHTML = '';
    document.getElementById('count-' + status).textContent = columns[status].length;
    columns[status].forEach(task => col.appendChild(renderTaskCard(task)));
  });
}

function memberName(id) {
  if (!id) return null;
  const m = state.currentProject.members.find(m => m.id === id);
  return m ? m.name : null;
}

function renderTaskCard(task) {
  const card = document.createElement('div');
  card.className = 'task-card';
  card.draggable = true;
  card.dataset.id = task.id;
  card.dataset.status = task.status;
  const assignee = memberName(task.assigneeId);
  const commentCount = (task.comments || []).length;
  card.innerHTML = `
    <h4>${escapeHtml(task.title)}</h4>
    ${task.description ? `<p>${escapeHtml(task.description)}</p>` : ''}
    <div class="task-card-foot">
      ${assignee ? `<span class="task-assignee">${escapeHtml(assignee)}</span>` : '<span></span>'}
      <span class="task-comment-count">${commentCount ? commentCount + ' comment' + (commentCount > 1 ? 's' : '') : ''}</span>
    </div>
  `;
  card.addEventListener('click', () => openTaskDetail(task.id));
  card.addEventListener('dragstart', () => card.classList.add('dragging'));
  card.addEventListener('dragend', () => card.classList.remove('dragging'));
  return card;
}

// Drag and drop between columns
document.querySelectorAll('.column-body').forEach(col => {
  col.addEventListener('dragover', (e) => {
    e.preventDefault();
    col.classList.add('drag-over');
  });
  col.addEventListener('dragleave', () => col.classList.remove('drag-over'));
  col.addEventListener('drop', async (e) => {
    e.preventDefault();
    col.classList.remove('drag-over');
    const dragging = document.querySelector('.task-card.dragging');
    if (!dragging) return;
    const taskId = dragging.dataset.id;
    const newStatus = col.closest('.column').dataset.status;
    const task = state.currentProject.tasks.find(t => t.id === taskId);
    if (task && task.status !== newStatus) {
      task.status = newStatus; // optimistic
      renderBoard();
      try {
        await api('PATCH', '/tasks/' + taskId, { status: newStatus });
      } catch (err) {
        toast('Could not move task: ' + err.message);
      }
    }
  });
});

document.querySelectorAll('.btn-add-task').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('nt-title').value = '';
    document.getElementById('nt-desc').value = '';
    document.getElementById('nt-error').textContent = '';
    document.getElementById('modal-new-task').dataset.status = btn.dataset.status;
    openModal('modal-new-task');
  });
});

document.getElementById('nt-submit').addEventListener('click', async () => {
  const title = document.getElementById('nt-title').value.trim();
  const description = document.getElementById('nt-desc').value.trim();
  const assigneeId = document.getElementById('nt-assignee').value || null;
  const status = document.getElementById('modal-new-task').dataset.status || 'todo';
  const errEl = document.getElementById('nt-error');
  if (!title) { errEl.textContent = 'Give the task a title'; return; }
  try {
    const task = await api('POST', '/tasks/project/' + state.currentProject.id, { title, description, assigneeId });
    if (status !== 'todo') {
      await api('PATCH', '/tasks/' + task.id, { status });
    }
    closeModals();
    await openProject(state.currentProject.id);
  } catch (err) {
    errEl.textContent = err.message;
  }
});

// ===================== Task detail / comments =====================
function openTaskDetail(taskId) {
  const task = state.currentProject.tasks.find(t => t.id === taskId);
  if (!task) return;
  const modal = document.getElementById('modal-task-detail');
  modal.dataset.taskId = taskId;
  document.getElementById('td-title').textContent = task.title;
  document.getElementById('td-desc').textContent = task.description || 'No description yet.';
  const assignee = memberName(task.assigneeId);
  document.getElementById('td-assignee').textContent = assignee ? 'Assigned to ' + assignee : 'Unassigned';
  const statusLabel = { todo: 'To Do', in_progress: 'In Progress', done: 'Done' }[task.status];
  document.getElementById('td-status-badge').textContent = statusLabel;
  renderComments(task);
  openModal('modal-task-detail');
}

function renderComments(task) {
  const wrap = document.getElementById('td-comments');
  wrap.innerHTML = '';
  (task.comments || []).forEach(c => {
    const el = document.createElement('div');
    el.className = 'comment-item';
    const time = new Date(c.createdAt).toLocaleString();
    el.innerHTML = `<span class="c-author">${escapeHtml(c.author || 'Someone')}</span>${escapeHtml(c.text)}<span class="c-time">${time}</span>`;
    wrap.appendChild(el);
  });
  wrap.scrollTop = wrap.scrollHeight;
}

document.getElementById('td-comment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('td-comment-input');
  const text = input.value.trim();
  if (!text) return;
  const taskId = document.getElementById('modal-task-detail').dataset.taskId;
  try {
    await api('POST', `/tasks/${taskId}/comments`, { text });
    input.value = '';
  } catch (err) {
    toast(err.message);
  }
});

document.getElementById('td-delete').addEventListener('click', async () => {
  const taskId = document.getElementById('modal-task-detail').dataset.taskId;
  if (!confirm('Delete this task?')) return;
  await api('DELETE', '/tasks/' + taskId);
  closeModals();
});

// ===================== Modal close =====================
document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', closeModals));
document.getElementById('modal-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'modal-overlay') closeModals();
});

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

// ===================== Init =====================
if (state.token && state.user) {
  bootApp();
} else {
  showScreen('screen-auth');
}
