# Flowboard — Project Management Tool

A full-stack Trello/Asana-style collaborative tool built for **Task 3: Project Management Tool**.

## Features
- **Auth system** — register/login with hashed passwords + JWT sessions
- **Project boards** — create group projects, add teammates by username
- **Task cards** — create tasks, assign to a member, drag-and-drop between To Do / In Progress / Done
- **Comments** — discuss a task right on its card
- **Real-time updates** — every create/move/comment/member-add is pushed instantly to everyone viewing the project, via WebSockets (Socket.io)
- **Professional UI** — custom dark-navy + amber theme, split-screen auth page, kanban board

## Tech stack
- **Backend:** Node.js, Express, Socket.io, JWT, bcryptjs
- **Data:** a simple JSON file store (`backend/data.json`, created automatically) — no database setup required
- **Frontend:** plain HTML/CSS/JavaScript (no build step), served by the same Express server

## How to run

```bash
cd backend
npm install
npm start
```

Then open **http://localhost:4000** in your browser.

The server serves both the API (`/api/...`) and the frontend from the same port, and the JWT used for REST calls also authenticates the WebSocket connection — so there's nothing extra to configure.

## Try it with two accounts (to see real-time updates)
1. Register account **A**, create a project.
2. Open a second (private/incognito) browser window, register account **B**.
3. In window A, click **Add member** and add B's username to the project.
4. In window B, open the same project. Move a task or add a comment in one window — it appears instantly in the other.

## Project structure
```
pm-tool/
├── backend/
│   ├── server.js          # Express app + Socket.io server
│   ├── db.js               # tiny JSON file-based data store
│   ├── middleware/auth.js  # JWT verification
│   └── routes/
│       ├── auth.js         # register / login / user lookup
│       ├── projects.js     # create/list/get/delete project, add member
│       └── tasks.js        # create/update/delete task, comments
└── frontend/
    ├── index.html           # auth screen + app shell (dashboard + board)
    ├── css/style.css
    └── js/app.js            # all client-side logic (fetch + socket.io)
```

## Notes / next steps
- Data is stored in `backend/data.json`. Delete that file to reset the app.
- For production, set a real `JWT_SECRET` environment variable instead of the built-in dev default.
- The bonus requirement (notifications + real-time updates via WebSockets) is implemented for task moves, task creation/deletion, comments, and members joining a project.
